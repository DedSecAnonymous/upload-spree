
 
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <cstdio>

#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <math.h>

int chain()
{
    for(int j=0;j<5000000;j++);
    std::cout<<"Damn\n";
}
int gain()
{
    for(int j=0;j<1000000;j++);
    std::cout<<"Nasty";
}
int pain()
{
    std::cout<<"Aint that good bruh\n";
    gain();gain();
    return 0;
}
int main()
{
    std::cout<<"Cheerio\n";
    for(int i=0;i<8;i++)
    pain();
    chain();
}
