
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <cstdio>
#include <CL/opencl.h>
#include <CL/cl.hpp>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <math.h>




const char *kernelSource =                                       "\n" \
"//#pragma OPENCL EXTENSION cl_khr_fp64 : enable                    \n" \
"__kernel void vecAdd(  __global float *a,                       \n" \
"                       __global float *b,                       \n" \
"                       __global float *c,                       \n" \
"                       const unsigned int n)                    \n" \
"{                                                               \n" \
"    //Get our global thread ID                                  \n" \
"    int id1 = get_global_id(0);int id2 = get_global_id(1);       \n" \
"    int k =0;   c[id1 + n*id2] = 0    ;                          \n" \
"    //Make sure we do not go out of bounds                      \n" \
"    if (id1 < n && id2 <n)                                       \n" \
"    for( k =0;k<n;k++){                                          \n" \
"        c[id1 + n*id2]+=  a[id1 + n*k] *b[k + n*id2];        \n"\
"    }                                                            \n"\
"                                                                \n"\
"                                                                \n"\
"                                                                \n"\
"                                                                \n"\
"                                                                \n"\
"                                                                \n"\
"}                                                               \n" \
                                                                "\n" ;
 
int main( int argc, char* argv[] )
{
    
    const unsigned int n = 1024;
	size_t origin[3]={0,0,0};
	
	
    float *h_a;
    float *h_b;
    
    float *h_c;
 
    
    cl_mem d_a;
    cl_mem d_b;
    
    cl_mem d_c;
	cl_mem pic;
	
 
    cl_platform_id cpPlatform;        
    cl_device_id device_id;           
    cl_context context;               
    cl_command_queue queue;           
    cl_program program;               
    cl_kernel kernel;                 
	size_t globalSize[2] = {n,n};
	size_t localSize[2] = {16,16};
    
    size_t bytes = n*n*sizeof(float);
 
    
    h_a = (float*)malloc(bytes);
    h_b = (float*)malloc(bytes);
    h_c = (float*)malloc(bytes);
 
    
    int i,j;
    for( i = 0; i < n; i++ )
    {
        for(j=0;j<n;j++)
		{
			h_a[i+n*j] = 0;
			h_b[i+n*j] = 0;
			if(i==j)
			{
				h_a[i+n*j] = 1;
				h_b[i+n*j] = 2;
			}
		}
    }

    cl_int err;
    
    err = clGetPlatformIDs(1, &cpPlatform, NULL);
 
    
    err = clGetDeviceIDs(cpPlatform, CL_DEVICE_TYPE_GPU, 1, &device_id, NULL);
 
     
    context = clCreateContext(0, 1, &device_id, NULL, NULL, &err);

	cl_uchar4* picdata = (cl_uchar4*)malloc(n*n * sizeof(cl_uchar4));
	
	struct _cl_image_format picformat = {CL_RGBA, CL_UNORM_INT8};
	struct _cl_image_desc picdesc = {CL_MEM_OBJECT_IMAGE2D, n, n ,0, 0, 0, 0, 0 , 0, NULL};
    pic = clCreateImage(context, CL_MEM_READ_ONLY | CL_MEM_USE_HOST_PTR, &picformat, &picdesc,picdata,&err);

	std::cout<<err<<"\n";

    queue = clCreateCommandQueue(context, device_id, 0, &err);
 
    
    program = clCreateProgramWithSource(context, 1,
                            (const char **) & kernelSource, NULL, &err);
 
    
    clBuildProgram(program, 0, NULL, NULL, NULL, NULL);
 
    
    kernel = clCreateKernel(program, "vecAdd", &err);
    
	size_t len;
    err = clGetProgramBuildInfo(program, device_id, CL_PROGRAM_BUILD_LOG, NULL,NULL, &len);
	char *log = new char[len];
	clGetProgramBuildInfo(program, device_id, CL_PROGRAM_BUILD_LOG, len, log,NULL);
	std::ofstream buildLog("Satvik3Log.txt");
	buildLog<<log;

    d_a = clCreateBuffer(context, CL_MEM_READ_ONLY, bytes, NULL, NULL);
    d_b = clCreateBuffer(context, CL_MEM_READ_ONLY, bytes, NULL, NULL);
    d_c = clCreateBuffer(context, CL_MEM_WRITE_ONLY, bytes, NULL, NULL);
 
	size_t region[3]={n,n,1};
	int color[4] = {0,0,80,255};
	err = clEnqueueFillImage(queue, pic,color ,origin, region, NULL, 0, NULL);std::cout<<err<<"\n";
    err = clEnqueueWriteBuffer(queue, d_a, CL_TRUE, 0,
                                   bytes, h_a, 0, NULL, NULL);
    err |= clEnqueueWriteBuffer(queue, d_b, CL_TRUE, 0,
                                   bytes, h_b, 0, NULL, NULL);
	
    
    err  = clSetKernelArg(kernel, 0, sizeof(cl_mem), &d_a);
    err |= clSetKernelArg(kernel, 1, sizeof(cl_mem), &d_b);
    err |= clSetKernelArg(kernel, 2, sizeof(cl_mem), &d_c);
    err |= clSetKernelArg(kernel, 3, sizeof(unsigned int), &n);
 
     
    err = clEnqueueNDRangeKernel(queue, kernel, 2, NULL, globalSize, localSize,
                                                              0, NULL, NULL);
 
    
    clFinish(queue);
 
    
    clEnqueueReadBuffer(queue, d_c, CL_TRUE, 0,
                                bytes, h_c, 0, NULL, NULL );
 
    
    float sum = 0;
    for(i=0; i<n*n; i++)
        sum += h_c[i];
    
	printf("final result: %f\n", sum);
	std::cout<<err<<"\n";
	std::ofstream cData("Satvik3.txt");
	for(int i =0;i<n*n ;i++)
		cData<<i<<" : "<<h_c[i]<<"\n";
	
 
    
    clReleaseMemObject(d_a);
    clReleaseMemObject(d_b);
    clReleaseMemObject(d_c);
    clReleaseProgram(program);
    clReleaseKernel(kernel);
    clReleaseCommandQueue(queue);
    clReleaseContext(context);
 
    
    free(h_a);
    free(h_b);
    free(h_c);
 
    return 0;
}